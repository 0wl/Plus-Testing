#!/bin/ksh
# MIB2 utility script, part of the MIB STD2 Toolbox.
# Coded by Olli
# This script will restore files from backup.
# Based on the copy script by Jille from MIB2 High Toolbox. Modified for MIB STD2 Toolbox by Olli

echo

# Locate Toolbox drive
. /tsd/etc/persistence/esd/scripts/util_checksd.sh

# Include info utility
. /tsd/etc/persistence/esd/scripts/util_info.sh

OLDFILES=$VOLUME/backup/$TRAIN/$SERIAL/$SDPATH
echo "Source: backup/$TRAIN/$SERIAL/"
echo "        $SDPATH"
echo "Destination: $MIBPATH"

if [ "$TYPE" = "folder" ]; then
	if [ -d ${OLDFILES} ]; then
		if [ -z "$(echo $MIBPATH | grep '/tsd/var')" ]; then
			# Mount system partition in read/write mode
			. /tsd/etc/persistence/esd/scripts/util_mount.sh
		fi
		echo "Restoring, please wait..."
		if [ "$TOPIC" = "greenmenu" ]; then
			rm -rf /tsd/etc/persistence/esd/*
		fi
		cp -rf ${OLDFILES}/. ${MIBPATH}
		if [ "$TOPIC" = "greenmenu" ]; then
			echo "Copying toolbox Green Engineering Menu screens and scripts..."
			cp -rf $VOLUME/cpu/onlineservices/1/default/tsd/etc/persistence/esd/* /tsd/etc/persistence/esd
			echo "Done."
			echo "Setting execution attributes to scripts..."
			chmod a+rwx /tsd/etc/persistence/esd/scripts/*.sh
			echo "Done." 
		fi
		if [ -z "$(echo $MIBPATH | grep '/tsd/var')" ]; then
			# Mount system partition in read/only mode
			. /tsd/etc/persistence/esd/scripts/util_mount_ro.sh
		fi
	else
		echo
		echo "ERROR: Backup is not found"
		exit 0
	fi
else
	if [ -f ${OLDFILES} ]; then
		if [ -z "$(echo $MIBPATH | grep '/tsd/var')" ]; then
			# Mount system partition in read/write mode
			. /tsd/etc/persistence/esd/scripts/util_mount.sh
		fi
		echo "Restoring, please wait..."
		cp -f ${OLDFILES} ${MIBPATH}
		if [[ $TOPIC = "swdl" || $TOPIC = "swap" || $TOPIC = "hmi" || $TOPIC = "mirrorlink" || $TOPIC = "navigation" || $TOPIC = "shadow" ]]; then
			chmod 777 ${MIBPATH}
		fi
		if [ -z "$(echo $MIBPATH | grep '/tsd/var')" ]; then
			# Mount system partition in read/only mode
			. /tsd/etc/persistence/esd/scripts/util_mount_ro.sh
		fi
	else
		echo
		echo "ERROR: Backup is not found"
		exit 0
	fi
fi 

echo
if [ "$TOPIC" = "shadow" ]; then
	echo "Restoring is done."
elif [ "$TOPIC" = "devesd" ]; then
	echo "Restoring is done. Please reopen Green Engineering Menu."
else
	echo "Restoring is done. Please restart the unit."
fi
exit 0